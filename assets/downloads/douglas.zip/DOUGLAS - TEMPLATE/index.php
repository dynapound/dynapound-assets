<?php include 'header.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<body>
  <!-- Hero Section -->
  <section class="hero" id="hero">
    <section class="hero-header-gif" id="hero-header-gif">
      <h1>Welcome to a Website!/h1>
      <p>go visit <a href="/cc.php" style="color: cornflowerblue;" target="_blank">the contributors page</a> below.</p>
      <a href="/cc.php" class="cta">View</a>
    </section>
  </section>

  <!-- Experience Carousel -->
  <section id="carousel">
    <h2>Carousel</h2>
    <div class="carousel">
      <div class="carousel-item">
        <img src="https://img.icons8.com/?size=100&id=9918&format=png&color=000000" alt="carousel">
        <h3>title</h3>
        <p>This is an example of a paragraph!, hope you like it.</p>
      </div>
      <div class="carousel-item">
        <img src="https://img.icons8.com/?size=100&id=9918&format=png&color=000000" alt="carousel">
        <h3>title</h3>
        <p>This is an example of a paragraph!, hope you like it.</p>
      </div>
      <div class="carousel-item">
        <img src="https://img.icons8.com/?size=100&id=9918&format=png&color=000000" alt="carousel">
        <h3>title</h3>
        <p>This is an example of a paragraph!, hope you like it.</p>
      </div>
      <div class="carousel-item">
        <img src="https://img.icons8.com/?size=100&id=9918&format=png&color=000000" alt="carousel">
        <h3>title</h3>
        <p>This is an example of a paragraph!, hope you like it.</p>
      </div>
      <div class="carousel-item">
        <img src="https://img.icons8.com/?size=100&id=9918&format=png&color=000000" alt="carousel">
        <h3>title</h3>
        <p>This is an example of a paragraph!, hope you like it.</p>
      </div>
      <div class="carousel-item">
        <img src="https://img.icons8.com/?size=100&id=9918&format=png&color=000000" alt="carousel">
        <h3>title</h3>
        <p>This is an example of a paragraph!, hope you like it.</p>
      </div>
    </div>
  </section>

  <!-- Why Are We Doing This? -->
  <div class="homescroll-002-container">
    <h1>title</h1>
    <div class="homescroll-002-reveal-section">
      <div class="homescroll-002-reveal-item">
        <img src="/assets/images/home-open-source.gif" alt="Feature 1">
        <div class="homescroll-002-reveal-content">
          <h3>title</h3>
          <p>This is an example of a paragraph!, hope you like it.</p>
        </div>
      </div>
      <div class="homescroll-002-reveal-item">
        <img src="/assets/images/home-open-source-comunity.gif" alt="Feature 2">
        <div class="homescroll-002-reveal-content">
          <h3>title</h3>
          <p>This is an example of a paragraph!, hope you like it.</p>
        </div>
      </div>
      <div class="homescroll-002-reveal-item">
        <img src="/assets/images/empty.png" alt="Feature 3">
        <div class="homescroll-002-reveal-content">
          <h3>title</h3>
          <p>This is an example of a paragraph!, hope you like it.</p>
        </div>
      </div>
      <div class="homescroll-002-reveal-item">
        <img src="/assets/images/empty.png" alt="Feature 4">
        <div class="homescroll-002-reveal-content">
          <h3>title</h3>
          <p>This is an example of a paragraph!, hope you like it.</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Image Carousel -->
  <div class="homeslide-wrapper">
    <div class="homeslide-page">
      <img src="/assets/images/empty.gif" alt="title">
      <button class="slide-nav left" onclick="scrollToPage(-1)">&#10094;</button>
      <button class="slide-nav right" onclick="scrollToPage(1)">&#10095;</button>
    </div>
    <div class="homeslide-page">
      <img src="/assets/images/empty.gif" alt="title">
      <button class="slide-nav left" onclick="scrollToPage(-1)">&#10094;</button>
      <button class="slide-nav right" onclick="scrollToPage(1)">&#10095;</button>
    </div>
    <div class="homeslide-page">
      <img src="/assets/images/empty.gif" alt="title">
      <button class="slide-nav left" onclick="scrollToPage(-1)">&#10094;</button>
      <button class="slide-nav right" onclick="scrollToPage(1)">&#10095;</button>
    </div>
    <div class="homeslide-page">
      <img src="/assets/images/empty.gif" alt="title">
      <button class="slide-nav left" onclick="scrollToPage(-1)">&#10094;</button>
      <button class="slide-nav right" onclick="scrollToPage(1)">&#10095;</button>
    </div>
  </div>
</body>


<?php include 'footer.php'; ?>