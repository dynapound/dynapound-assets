  <!-- Skills Showcase -->
  <section id="skills">
    <h2>Our Skills Are...</h2>
    <div class="skills-container">
      <div class="skill-item">
        <img src="https://img.icons8.com/ios-filled/50/000000/html-5.png" alt="HTML5 icon">
        <p>HTML5</p>
      </div>
      <div class="skill-item">
        <img src="https://img.icons8.com/ios-filled/50/000000/css3.png" alt="CSS3 icon">
        <p>CSS3</p>
      </div>
      <div class="skill-item">
        <img src="https://img.icons8.com/ios-filled/50/000000/javascript.png" alt="JavaScript icon">
        <p>JavaScript</p>
      </div>
      <div class="skill-item">
        <img src="https://img.icons8.com/ios-filled/50/000000/c.png" alt="C++">
        <p>C++</p>
      </div>
      <div class="skill-item">
        <img src="https://img.icons8.com/ios-filled/50/000000/python.png" alt="Python">
        <p>Python</p>
      </div>
      <div class="skill-item">
        <img src="https://img.icons8.com/?size=100&id=100506&format=png&color=000000" alt="java">
        <p>Java</p>
      </div>
      <div class="skill-item">
        <img src="https://img.icons8.com/ios-filled/50/000000/linux.png" alt="Linux">
        <p>Linux</p>
      </div>
    </div>
  </section>



 <footer class="footer-dark">
    <div class="container">
      <div class="copyright">
        <a href="/cc.php" style="color: gray;" target="_blank">&copy; <span id="current-year"></span> All rights reserved. | Site made by Alfie</a>
      </div>
    </div>
  </footer>

  <script>
    document.getElementById("current-year").textContent = new Date().getFullYear();
  </script>
</body>
</html>
