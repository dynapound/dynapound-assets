<?php
session_start();

// Email settings
$admin_email_1 = "contact1@example.com"; // First recipient email address
$admin_email_2 = "contact2@example.com"; // Second recipient email address

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format. Please go back and try again.";
        exit();
    }

    // Create the email content
    $subject = "New Message from Contact Form";
    $email_content = "You have received a new message from your website contact form.\n\n";
    $email_content .= "Name: $name\n";
    $email_content .= "Email: $email\n";
    $email_content .= "Message:\n$message\n";

    // Set headers
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Send the email to both addresses
    $recipients = $admin_email_1 . "," . $admin_email_2; // Combine the two email addresses
    if (mail($recipients, $subject, $email_content, $headers)) {
        // Message sent successfully, redirect to a thank you page
        header('Location: thank_you.php');
        exit();
    } else {
        // If the email fails to send, show an error message
        echo "There was an error sending your message. Please try again later.";
    }
}
?>

<?php include 'header.php'; ?>

<section class="contact-form">
    <h1>Contact Us</h1>
    <p>We would love to hear from you! Please fill out the form below to send us a message.</p>

    <form action="contact.php" method="POST">
        <label for="name">Your Name</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Your Email</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Your Message</label>
        <textarea id="message" name="message" rows="5" required></textarea>

        <button type="submit" class="submit-btn">Send Message</button>
    </form>
</section>

<?php include 'footer.php'; ?>