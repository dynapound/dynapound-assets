<?php include 'header.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);
?>


  <!-- Hero Section -->

  <section class="hero" id="hero">

    <h1>Credits & Copyright</h1>

    <p>thanks to all our amazing partners and friends at Dyna Pound this is possible</p>
    
    <h2>Some Contibuters Sites</h2>
    
    <p><a href="https://alfieterry.co.uk" style="color: cornflowerblue;" target="_blank">alfieterry.co.uk</a> | <a href="https://lawridarbyshire.co.uk" style="color: cornflowerblue;" target="_blank">lawridarbyshire.co.uk</a> | <a href="https://www.benmaskell.co.uk" style="color: cornflowerblue;" target="_blank">www.benmaskell.co.uk</a></p>

    <br>
    <br>
    <br>
    <br>
 <div class="page-copyright-align">
    <h1>Copyrights:</h1>

    <span>&copy; <span id="current-year"></span> Alfie Sid Alan Terry. All rights reserved.</span>
    <span>&copy; <span id="current-year"></span> Lawri Endevour Darbyshire. All rights reserved.</span>
    <span>&copy; <span id="current-year"></span> Ben Maskell. All rights reserved.</span>
    <span>&copy; <span id="current-year"></span> Tom Collis. All rights reserved.</span>
    <a href="./license.php" style="color: cornflowerblue;" target="_blank">MIT License Page</a>
    <a href="./DOL.php" style="color: cornflowerblue;" target="_blank">DOL Page</a>
  </section>
</div>



  <div class="homeslide-wrapper">
    <div class="homeslide-page">
      <img src="/assets/images/example.gif" alt="Group/team">
    </div>
  </div>

<?php include 'footer.php'; ?>
	