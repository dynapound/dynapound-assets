<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Thank you for your submission">
    <meta name="keywords" content="thank you, submission, form, contact">
    <meta name="author" content="Alfie Sid Alan Terry">
    <meta name="robots" content="index, follow">
    <title>Thank You | Dyna Pound</title>
    <link rel="icon" href="https://assets.dynnapound/assets/images/logo.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script defer src="https://assets.dynapound.com/assets/js/main.js"></script>

    <style>
        /* General Styles for the Thank You Page */
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f1f5f9; /* Light background */
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
            opacity: 0;
            animation: fadeIn 1s ease-in-out forwards;
        }

        /* Logo Style */
        .logo {
            width: 100px;
            margin-bottom: 20px;
        }

        /* Thank You Text Style */
        h1 {
            font-size: 3rem;
            color: #2563eb; /* Primary color */
            margin-bottom: 1rem;
            opacity: 0;
            animation: fadeInText 1s ease-in-out forwards 0.5s;
        }

        p {
            font-size: 1.2rem;
            color: #555;
            margin-bottom: 2rem;
            opacity: 0;
            animation: fadeInText 1s ease-in-out forwards 1s;
        }

        /* Button Style */
        .cta-button {
            background-color: #2563eb; /* Primary color */
            color: white;
            padding: 0.75rem 2rem;
            font-size: 1rem;
            text-decoration: none;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease;
            opacity: 0;
            animation: fadeInText 1s ease-in-out forwards 1.5s;
        }

        .cta-button:hover {
            background-color: #60a5fa; /* Lighter blue on hover */
        }

        /* Animation for fade-in effect */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes fadeInText {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <div class="thank-you-container">
        <img src="https://assets.dynapound/assets/images/logo.png" alt="Dyna Pound Logo" class="logo">
        <h1>Thank You for Your Message!</h1>
        <p>We appreciate you reaching out. Our team will get back to you as soon as possible.</p>
        <a href="index.php" class="cta-button">Return to Home</a>
    </div>

    <script>
        // Optional: Add any dynamic behavior with JavaScript if needed
    </script>
</body>

</html>
