<?php include 'header.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);
/*
 * Dynapound Open License (DOL-1.0)
 * This software is licensed under the Dynapound Open License.
 * 
 * - You may modify and redistribute this software freely.
 * - You must always display the original copyright credits.
 * - You may not claim copyright over the original source code.
 * - Credits must be shown in an H1 or H2 heading in the copyright section.
 * 
 * Copyright (c) ".date("Y")." Alfie Sid Alan Terry, Lawri Endevour Darbyshire, Ben Maskell, Tom Collis.
 */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynapound Open License</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; text-align: center; padding: 50px; }
        .license-container { max-width: 800px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        h1, h2 { color: #333; }
        p { color: #555; }
    </style>
</head>
<body>
    <div class="license-container">
        <h1>Dynapound Open License (DOL-1.0)</h1>
        <h2>Copyright Owners</h2>
        <p>&copy; <?php echo date("Y"); ?> Alfie Sid Alan Terry, Lawri Endevour Darbyshire, Ben Maskell, Tom Collis.</p>
        <p>This software is licensed under the Dynapound Open License. You may edit and use it freely, but you must retain this credit.</p>
    </div>
</body>
</html>
<?php include 'footer.php' ?>