<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="website">
  <meta name="keywords" content="website">
  <meta name="author" content="Alfie Sid Alan Terry">
  <meta name="robots" content="index, follow">
  <title>| By  Alfie Terry |</title>
  <link rel="icon" href="/assets/images/logo.png" type="image/x-icon">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/douglas.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <script defer src="/assets/js/main.js"></script>
</head>
<body>
  <header>
    <div class="logo" style="display: inline-flex; align-items: center;">
      <img src="/assets/images/logo.png" alt="Dyna Pound Logo" class="logo" style="width: 40px; margin-right: 8px;">
      <p>Douglas Template</p>
    </div>

    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="cc.php">License & Copyright</a></li>
      </ul>
    </nav>
  </header>





<?php
// Track page visits
$statsFile = 'stats.json';

// Initialize or read existing stats
if (!file_exists($statsFile)) {
    $stats = ['visits' => 0, 'downloads' => 0];
} else {
    $stats = json_decode(file_get_contents($statsFile), true);
}

// Increment visit count
$stats['visits']++;

// Save updated stats
file_put_contents($statsFile, json_encode($stats));
?>